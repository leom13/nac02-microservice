package br.com.fiap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThefiveNac02Application {

	public static void main(String[] args) {
		SpringApplication.run(ThefiveNac02Application.class, args);
	}

}
