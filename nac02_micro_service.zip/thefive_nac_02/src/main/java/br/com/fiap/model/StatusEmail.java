package br.com.fiap.model;

public enum StatusEmail {
	Enviado,
	Erro
}
